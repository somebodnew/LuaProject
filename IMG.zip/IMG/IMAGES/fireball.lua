--local fireball=require('main')
local fireMagic=love.graphics.newImage('fireMagic.png')
local quadfire=love.graphics.newQuad(496,319,32,33,fireMagic:getWidth(), fireMagic:getHeight())
local fireball={
    x=400,
    y=300,
    scale=2,
    speed=0,
}
  


function love.keypressed(btn)
    if btn=='k' and fireball.speed==0 then
        fireball.speed=fireball.speed+7
    end
	fireball.y=main.player2.y
    fireball.x=main.player2.x
    fireball.x=fireball.x+fireball.speed
	love.graphics.draw(fireMagic,quadfire,fireball.x,fireball.y,0,fireball.scale,fireball.scale)
end

function love.update(dt)
    
end

function love.draw()
        
end
return{
    keypressed=keypressed,
    updatefireball=update,
    drawfireball=draw
}